''' configs '''
stopwords = ['a', 'an', 'be','the', 'on','i','not','out', 'have', 'some', 'over', 'one', 'now', 'other', 'about', 'around', 'all']
db_name = '1581cheese'
#############################################################
## for dict
beta = 0.0 #0.01
extra = 1.0 # scale of cegema
limit = 500    #  ----> the top 100 frequency from words
syno_cnt = 10    # 10---->the maxin similar words num

time_extra = 3600 #    ---> time delta after last tw

##################################################################
## for news
tfr = '2015-10-07 00:00'
tto = '2015-10-08 23:59'

#####################################################################
## actr
retrival_emo = -0.217391304
similarity_param = 0.8
#===============================================================



